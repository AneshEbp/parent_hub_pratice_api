import AWS from 'aws-sdk';
import fs from 'fs';
import path from 'path';
import ffmpegInstaller from '@ffmpeg-installer/ffmpeg';
import ffmpeg from 'fluent-ffmpeg';
import { fileURLToPath } from 'url';

// Required for __dirname in ES modules
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

ffmpeg.setFfmpegPath(ffmpegInstaller.path);

const s3 = new AWS.S3();

export const handler = async (event) => {
  console.log('Event:', JSON.stringify(event, null, 2));

  const bucket = event.Records[0].s3.bucket.name;
  const key = decodeURIComponent(event.Records[0].s3.object.key.replace(/\+/g, ' '));
  const fileName = path.basename(key);
  const tempVideoPath = `/tmp/${fileName}`;
  const thumbnailPath = `/tmp/thumbnail.jpg`;
  const outputKey = `public/video/thumbnails/${fileName.replace(/\.[^/.]+$/, '')}_thumbnail.jpg`;

  try {
    // Download video from S3
    const videoFile = await s3.getObject({ Bucket: bucket, Key: key }).promise();
    fs.writeFileSync(tempVideoPath, videoFile.Body);

    // Generate thumbnail
    await new Promise((resolve, reject) => {
      ffmpeg(tempVideoPath)
        .on('end', resolve)
        .on('error', reject)
        .screenshots({
          count: 1,
          timestamps: ['5'],
          filename: 'thumbnail.jpg',
          folder: '/tmp',
          size: '320x240',
        });
    });

    // Upload thumbnail to S3
    const thumbnailBuffer = fs.readFileSync(thumbnailPath);
    await s3.putObject({
      Bucket: bucket,
      Key: outputKey,
      Body: thumbnailBuffer,
      ContentType: 'image/jpeg',
    }).promise();

    return {
      statusCode: 200,
      body: JSON.stringify({ message: 'Thumbnail generated successfully.' }),
    };
  } catch (error) {
    console.error('Error generating thumbnail:', error);
    return {
      statusCode: 500,
      body: JSON.stringify({ error: 'Thumbnail generation failed.' }),
    };
  }
};
