import {
  S3Client,
  GetObjectCommand,
  PutObjectCommand,
} from '@aws-sdk/client-s3';
import sharp from 'sharp';

// create S3 client
const s3 = new S3Client({ region: 'ap-southeast-2' });

//-- same configuration with lambda function s3 --//
const convertOption = {
  convertFile: true,
  convertFileExt: '.webp',
};

const ALLOWED_IMAGE_FILETYPES = [
  'png',
  'jpg',
  'jpeg',
  'bmp',
  'gif',
  'PNG',
  'JPG',
  'JPEG',
  'BMP',
  'GIF',
];

// Define the sizes for thumbnails

const fileSizes = {
  items: [
    { width: null, height: null },
    { width: 327, height: 200 },
    { width: 300, height: 120 },
    { width: 80, height: 80 },
    { width: 375, height: 230 },
  ],
  default: [
    { width: null, height: null },
    { width: 100, height: 200 },
    { width: 200, height: 300 },
    { width: 300, height: 400 },
  ],
};

//-- same configuration with lambda function s3 --//

// define the handler function
export const handler = async (event, context) => {
  try {
    const srcBucket = event.Records[0].s3.bucket.name;

    // Object key may have spaces or unicode non-ASCII characters.
    const srcKey = decodeURIComponent(
      event.Records[0].s3.object.key.replace(/\+/g, ' '),
    );

    // Infer the image type.
    const typeMatch = srcKey.match(/\.([^.]*)$/);
    if (!typeMatch) {
      // callback("Could not determine the image type.");
      return;
    }
    const imageType = typeMatch[1];
    //check image is video or image
    if (ALLOWED_IMAGE_FILETYPES.indexOf(imageType) >= 0) {
      //ISVIDEO = false
    } else {
      console.error(
        'Filetype ' + imageType + ' not valid for thumbnail, exiting',
      );
      return;
    }

    const keyParts = srcKey.split('/');
    keyParts.shift();
    keyParts.pop();

    const fileSizeKey = keyParts.join('/');

    let sizes = fileSizes[fileSizeKey]
      ? fileSizes[fileSizeKey]
      : fileSizes.default;

    //manipulate image
    for (const imageSize of sizes) {
      const parts = srcKey.split('/');
      parts.shift();

      const orginalImagePath = parts.join('/');
      let thumbnailKey = `public/${orginalImagePath}`;
      if (imageSize.width && imageSize.height) {
        const size = `${imageSize.width}x${imageSize.height}`;
        const fileName = parts.pop();
        parts.push(size);
        parts.push(fileName);
        const thumbnailPath = parts.join('/');
        thumbnailKey = `thumbnails/${thumbnailPath}`;
      }

      const params = {
        Bucket: srcBucket,
        Key: srcKey,
      };
      const response = await s3.send(new GetObjectCommand(params));
      const stream = response.Body;

      // Convert stream to buffer to pass to sharp resize function.
      const chunks = [];
      for await (const chunk of stream) {
        chunks.push(chunk);
      }
      const content_buffer = Buffer.concat(chunks);

      // Use the sharp module to resize the image and save in a buffer.

      let outputBuffer;
      if (convertOption.convertFile) {
        thumbnailKey = thumbnailKey.replace(
          new RegExp(`\\.(${ALLOWED_IMAGE_FILETYPES.join('|')})$`, 'i'),
          convertOption.convertFileExt,
        );

        outputBuffer = await sharp(content_buffer)
          .resize(imageSize.width, imageSize.height, { fit: 'cover' })
          .webp()
          .toBuffer();
      } else {
        outputBuffer = await sharp(content_buffer)
          .resize(imageSize.width, imageSize.height, { fit: 'cover' })
          .toBuffer();
      }

      // Upload the thumbnail image to the same bucket
      const destParams = {
        Bucket: srcBucket,
        Key: thumbnailKey,
        Body: outputBuffer,
        ContentType: 'image',
      };
      await s3.send(new PutObjectCommand(destParams));
      console.log(`Thumbnail created and uploaded to ${thumbnailKey}`);
    }
  } catch (error) {
    console.error('Error:', error);
    throw error;
  }
};
